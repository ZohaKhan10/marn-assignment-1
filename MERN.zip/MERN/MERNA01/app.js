const path = require('path'); 
const express = require('express');
const bodyParser = require('body-parser');

const app = express();

const adminRoutes = require('./routes/admin');
const defaultRoute = require('./routes/default');

app.use(bodyParser.urlencoded({extended: false}));

//use te adminRoutes.js file to handle endpoints that start with '/admin'
app.use('/admin', adminRoutes);

app.use(defaultRoute);
app.use((req, res, next) => {
    res.status(404).sendFile(path.join(__dirname, 'views', '404.html'));
});

app.listen(3000);