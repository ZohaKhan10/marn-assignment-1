const path = require('path');

const express = require('express');

const router = express.Router();
router.get('/input-salary', (req, res, next) => {
    res.sendFile(path.join(__dirname, '../', 'views', 'salary.html'));
});

router.post('/input-salary', (req, res, next) => {
    //console.log(req.body.salary);
    let num = req.body.salary;
    if (num >= 400000) {
        res.send('<h1>Your Salary Details: </h1><p>Salary before tax deduction: ' + num + '</p><p>Total Tax(25%): ' + num * 0.25 + '</p><p>Salary after tax deduction: ' + (num - (num * 0.25)) + '</p>');
    }
    else if (num >= 300000) {
        res.send('<h1>Your Salary Details: </h1><p>Salary before tax deduction: ' + num + '</p><p>Total Tax(20%): ' + num * 0.2 + '</p><p>Salary after tax deduction: ' + (num - (num * 0.2)) + '</p>');
    }
    else if (num >= 200000) {
        res.send('<h1>Your Salary Details: </h1><p>Salary before tax deduction: ' + num + '</p><p>Total Tax(15%): ' + num * 0.15 + '</p><p>Salary after tax deduction: ' + (num - (num * 0.15)) + '</p>');
    }
    else if (num >= 100000) {
        res.send('<h1>Your Salary Details: </h1><p>Salary before tax deduction: ' + num + '</p><p>Total Tax(10%): ' + num * 0.15 + '</p><p>Salary after tax deduction: ' + (num - (num * 0.10)) + '</p>');
    }
    else {
        res.send('<h1>Invalid Range</h1><p>Please enter a salary greater than or equal to 1,00,000</p>');
    }
});
module.exports = router;