
const path = require('path');
const express = require('express');

const router = express.Router();

router.get('/add-product', (req, res, next) => {
 
  let form = '<form action="add-product" method="POST">';
  form += '<h1>Salary Calculator</h1>';
  form += '<input type="text" name="salary" />';
  form += ' <button type="submit">Show Details</button>';
  form += '</form>';
  res.send(form);
});

router.post('/add-product', (req, res, next) => {
  let num = req.body.salary;
  if (num >= 400000) {
      res.send('<h1>Your Salary Details: </h1><p>Salary before tax : ' + num + '</p><p>Total Tax(25%): ' + num * 0.25 + '</p><p>Salary after tax : ' + (num - (num * 0.25)) + '</p>');
  }
  else if (num >= 300000) {
      res.send('<h1>Your Salary Details: </h1><p>Salary before tax : ' + num + '</p><p>Total Tax(20%): ' + num * 0.2 + '</p><p>Salary after tax : ' + (num - (num * 0.2)) + '</p>');
  }
  else if (num >= 200000) {
      res.send('<h1>Your Salary Details: </h1><p>Salary before tax : ' + num + '</p><p>Total Tax(15%): ' + num * 0.15 + '</p><p>Salary after tax : ' + (num - (num * 0.15)) + '</p>');
  }
  else if (num >= 100000) {
      res.send('<h1>Your Salary Details: </h1><p>Salary before tax : ' + num + '</p><p>Total Tax(10%): ' + num * 0.15 + '</p><p>Salary after tax : ' + (num - (num * 0.10)) + '</p>');
  }
  else {
      res.send('<h1>Invalid Range</h1><p>Please enter a salary greater than or equal to 1,00,000</p>');
  }
//  res.redirect('/shopping/products');
});
module.exports = router;



